Uncompress files before running

Run with android studio using a emulator

Uses firebase database (May need firebase connection for database implementation)

Firebase account:
email: group9naja@gmail.com
password: password123$

Steps to run:
1. Create android emulator on android studio (android 7.0 nougat)
2. Run android emulator
3. Run code with emulator running
4. Click registration button
5. Insert email/password sample
6. Firebase will store data in realtime database

XML_WECare.zip contains the UI template and images that we will be using for this project

Following link demos visualization of our UI:
https://www.figma.com/file/2lbsSpF2lPoXXenbKftJag/SUN-Project?node-id=3%3A39








