package com.example.wecare;

public class Member {
    private String atv;
        public Member(){}

    public String getAtv() {
        return atv;
    }

    public void setAtv(String atv) {
        this.atv = atv;
    }
}
